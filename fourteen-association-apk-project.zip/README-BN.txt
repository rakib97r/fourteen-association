Fourteen Association Android APK build project

APK তৈরির জন্য ZIP-এর ভেতরের সব ফাইল/ফোল্ডার GitHub repository-র root-এ যোগ করতে হবে।
Workflow ফাইলের সঠিক path: .github/workflows/build-apk.yml
তারপর GitHub > Actions > Build Fourteen Association APK > Run workflow চাপতে হবে।
Build সফল হলে Fourteen-Association-APK artifact থেকে app-debug.apk ডাউনলোড করতে হবে।

গুরুত্বপূর্ণ:
- APK-এর ডেটা অ্যাপের নিজস্ব WebView storage-এ থাকবে; ব্রাউজারের আগের localStorage স্বয়ংক্রিয়ভাবে APK-তে আসবে না।
- পুরোনো ডেটা থাকলে ব্রাউজার থেকে JSON backup নিয়ে APK-তে Settings > আগের ব্যাকআপ পুনরুদ্ধার দিয়ে restore করতে হবে।
- অ্যাপ uninstall বা app data clear করলে স্থানীয় ডেটা মুছে যেতে পারে। নিয়মিত JSON backup রাখবে।
- এটি unsigned debug APK; ব্যক্তিগত ফোনে পরীক্ষা/ব্যবহারের জন্য।
